#!/usr/bin/perl

# script by karabaja4
# mail: karabaja4@archlinux.us

my $blackFG_yellowBG = "\e[30;43m";
my $blackFG_redBG = "\e[30;41m";
my $blackFG_purpleBG = "\e[30;45m";

my $yellowFG_blackBG = "\e[1;33;40m";
my $yellowFG_redBG = "\e[1;33;41m";

my $redFG_yellowBG = "\e[31;43m";

my $purpleFG_yellowBG = "\e[35;43m";
my $purpleFG_blueBG = "\e[1;35;44m";

my $end = "\e[0m";

system("clear");

print "

               ${blackFG_yellowBG},'${blackFG_redBG}`${blackFG_yellowBG}`.._${end}   ${blackFG_yellowBG},'${blackFG_redBG}`${end}${blackFG_yellowBG}`.${end}
              ${blackFG_yellowBG}:${blackFG_redBG},${yellowFG_blackBG}--.${end}${blackFG_redBG}_${blackFG_yellowBG}:)\\,:${blackFG_redBG},${yellowFG_blackBG}._,${end}${yellowFG_redBG}.${end}${blackFG_yellowBG}:${end}
              ${blackFG_yellowBG}:`-${yellowFG_blackBG}-${end}${blackFG_yellowBG},${blackFG_yellowBG}''${end}${redFG_yellowBG}@@\@${end}${blackFG_yellowBG}:`.${yellowFG_redBG}.${end}${blackFG_yellowBG}.';\\${end}        All Glory to
               ${blackFG_yellowBG}`,'${end}${redFG_yellowBG}@@@@@@\@${end}${blackFG_yellowBG}`---'${redFG_yellowBG}@\@${end}${blackFG_yellowBG}`.${end}     the HYPNOTOAD!
               ${blackFG_yellowBG}/${redFG_yellowBG}@@@@@@@@@@@@@@@@\@${end}${blackFG_yellowBG}:${end}
              ${blackFG_yellowBG}/${redFG_yellowBG}@@@@@@@@@@@@@@@@@@\@${end}${blackFG_yellowBG}\\${end}
            ${blackFG_yellowBG},'${redFG_yellowBG}@@@@@@@@@@@@@@@@@@@@\@${end}${purpleFG_yellowBG}:\\${end}${blackFG_yellowBG}.___,-.${end}
           ${blackFG_yellowBG}`...,---'``````-..._${redFG_yellowBG}@@@\@${end}${blackFG_purpleBG}|:${end}${redFG_yellowBG}@@@@@@\@${end}${blackFG_yellowBG}\\${end}
             ${blackFG_yellowBG}(                 )${end}${redFG_yellowBG}@@\@${end}${blackFG_purpleBG};:${end}${redFG_yellowBG}@@@\@)@@\@${end}${blackFG_yellowBG}\\${end}  ${blackFG_yellowBG}_,-.${end}
              ${blackFG_yellowBG}`.              (${end}${redFG_yellowBG}@@\@${end}${blackFG_purpleBG}//${end}${redFG_yellowBG}@@@@@@@@@\@${end}${blackFG_yellowBG}`'${end}${redFG_yellowBG}@@@\@${end}${blackFG_yellowBG}\\${end}
               ${blackFG_yellowBG}:               `.${end}${blackFG_purpleBG}//${end}${redFG_yellowBG}@@)@@@@@@)@@@@@,\@${end}${blackFG_yellowBG};${end}
               ${blackFG_purpleBG}|`${purpleFG_yellowBG}.${blackFG_yellowBG}            ${end}${purpleFG_yellowBG}_${end}${purpleFG_yellowBG},${blackFG_purpleBG}'/${end}${redFG_yellowBG}@@@@@@@)@@@@)@,'\@${end}${blackFG_yellowBG},'${end}
               ${blackFG_yellowBG}:${end}${blackFG_purpleBG}`.`${end}${purpleFG_yellowBG}-..____..=${end}${blackFG_purpleBG}:.-${end}${blackFG_yellowBG}':${end}${redFG_yellowBG}@@@@@.@@@@\@_,@@,'${end}
              ${redFG_yellowBG},'${end}${blackFG_yellowBG}\\ ${end}${blackFG_purpleBG}``--....${end}${purpleFG_blueBG}-)='${end}${blackFG_yellowBG}    `.${end}${redFG_yellowBG}_,@\@${end}${blackFG_yellowBG}\\${end}    ${redFG_yellowBG})@@\@'``._${end}
             ${redFG_yellowBG}/\@${end}${redFG_yellowBG}_${end}${redFG_yellowBG}\@${end}${blackFG_yellowBG}`.${end}${blackFG_yellowBG}       ${end}${blackFG_redBG}(@)${end}${blackFG_yellowBG}      /${end}${redFG_yellowBG}@@@@\@${end}${blackFG_yellowBG})${end}  ${redFG_yellowBG}; / \\ \\`-.'${end}
            ${redFG_yellowBG}(@@\@${end}${redFG_yellowBG}`-:${end}${blackFG_yellowBG}`.     ${end}${blackFG_yellowBG}`' ___..'${end}${redFG_yellowBG}@\@${end}${blackFG_yellowBG}_,-'${end}   ${redFG_yellowBG}|/${end}   ${redFG_yellowBG}`.)${end}
             ${redFG_yellowBG}`-. `.`.${end}${blackFG_yellowBG}``-----``--${end}${redFG_yellowBG},@\@.'${end}
               ${redFG_yellowBG}|/`.\\`'${end}        ${redFG_yellowBG},',');${end}
                   ${redFG_yellowBG}`${end}         ${redFG_yellowBG}(/${end}  ${redFG_yellowBG}(/${end}


";
