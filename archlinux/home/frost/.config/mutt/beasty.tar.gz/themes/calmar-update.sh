umask 022
wget http://www.calmar.ws/dotfiles/dotfiledir/colors256-dark
wget http://www.calmar.ws/dotfiles/dotfiledir/colors256-light
mv -v colors256-dark calmar.dark
mv -v colors256-light calmar.light
